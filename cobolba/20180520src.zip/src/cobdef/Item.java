package cobdef;

import java.math.BigDecimal;

public class Item {
	public int col = 0;//レコードのバイト列の桁位置。0から始まる
	public int len = 0;//項目のバイトの長さ
	public String pic = "";//COBOL PICの値
	public String name = "";
	//	public String pic_javatype="";//PICから推定されるタイプ。"long"とか入れる　何につかう?
	//	文字から数字に変換する場合など、あらかじめ変換できるタイプがわかっていればやりやすい。
	private int intValue = 0;//getメソッドcall時に生成するといらないのでは? バイトのmoveなら早い　型変換のエラーは起きない。
	private long longValue = 0;//getメソッドcall時に生成するといらないのでは?　型チェックは働かない。
	private float floatValue = 0;//getメソッドcall時に生成するといらないのでは?
	private double doubleValue = 0;//getメソッドcall時に生成するといらないのでは?
	private BigDecimal BigDecimalValue = null;//getメソッドcall時に生成するといらないのでは?
	private byte[] RecBytes = null;////レコードのバイト列アドレス

	public Item() {
		name = "";
	}
	public Item(String str) {
		name = str;
	}

	public boolean THRU(String str, String str2) {
		return getString().equals(str);
	}
	public boolean THRU(int int1, int int2) {
		return (int1==int2);
	}

	public boolean equals(String str) {
		return getString().equals(str);
	}

	public boolean greaterOrEqual(int str) {
		return getString().equals(str);
	}

	public boolean lessOrEqual(int str) {
		return getString().equals(str);
	}

	public String substring(int i, int j) {
		return "";
	}

	public Item(int col, int len) {
		this.col = col;
		this.len = len;
	}

	public byte[] getRecBytes() {
		return RecBytes;
	}

	public void setRecBytes(byte[] recBytes) {
		RecBytes = recBytes;
	}

	/**
	 * @return stringValue
	 */
	public String getString() {
		return new String(RecBytes, col, len);
	}

	/**
	 * @param stringValue セットする stringValue
	 */
	public void setString(String stringValue) {
		//RecBytesのcol位置の長さlenに対してバイト列として編集する。
		if (stringValue.getBytes().length < len) {
			System.arraycopy(stringValue.getBytes(), 0, RecBytes, (int) col, (int) stringValue.getBytes().length);
		} else {
			System.arraycopy(stringValue.getBytes(), 0, RecBytes, (int) col, (int) len);
		}
	}

	/**
	 * @return intValue
	 */
	public int getInt() {
		return intValue;
	}

	/**
	 * @param intValue セットする intValue
	 */
	public void setInt(int intValue) {
		this.intValue = intValue;
	}

	/**
	 * @return longValue
	 */
	public long getLong() {
		return longValue;
	}

	/**
	 * @param longValue セットする longValue
	 */
	public void setLong(long longValue) {
		this.longValue = longValue;
	}

	/**
	 * @return floatValue
	 */
	public float getFloat() {
		return floatValue;
	}

	/**
	 * @param floatValue セットする floatValue
	 */
	public void setFloat(float floatValue) {
		this.floatValue = floatValue;
	}

	/**
	 * @return doubleValue
	 */
	public double getDouble() {
		return doubleValue;
	}

	/**
	 * @param doubleValue セットする doubleValue
	 */
	public void setDouble(double doubleValue) {
		this.doubleValue = doubleValue;
	}

	/**
	 * @return bigDecimalValue
	 */
	public BigDecimal getBigDecimal() {
		return BigDecimalValue;
	}

	/**
	 * @param bigDecimalValue セットする bigDecimalValue
	 */
	public void setBigDecimal(BigDecimal bigDecimalValue) {
		BigDecimalValue = bigDecimalValue;
	}

	public void COMPUTE(int i) {
		// TODO 自動生成されたメソッド・スタブ
		this.setInt(i);
	}

	public void COMPUTE(Object rounded, int i) {
		// TODO 自動生成されたメソッド・スタブ
	}
}
