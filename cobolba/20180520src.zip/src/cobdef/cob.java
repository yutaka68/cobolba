package cobdef;

public class cob {
	//レベル番号
	public class levelno {
		levelno(int livelnoparam) {
			this.livelno = livelnoparam;
		}

		private int livelno = 0;
	}

	public static final Object NOT_AT_END = new Object();
	public static final Object AT_END = new Object();
	public static final Object ROUNDED = new Object();
	public static final Object OCCURS = new Object();
	public static final Object REDEFINE = new Object();
	public static final Object REDEFINES = new Object();
	public static final Object TRUE = new Object();
	public static final Object ALSO = new Object();
	public static final Object THRU = new Object();
	public static final Object FALSE = new Object();
	public static final Object WHEN = new Object();
	public static final Object VALUE = new Object();
	public static final Object PIC = new Object();
	public static final Object FILLER = new Item();
	public final levelno _66 = new levelno(1);
	public final levelno _77 = new levelno(1);
	public final levelno _88 = new levelno(1);
	public final levelno _01 = new levelno(1);
	public final levelno __02 = new levelno(2);
	public final levelno ___03 = new levelno(3);
	public final levelno ____04 = new levelno(4);
	public final levelno _____05 = new levelno(5);
	public final levelno ______06 = new levelno(6);
	public final levelno _______07 = new levelno(7);
	public final String __ = null;
	public final String ____ = null;
	public final String _____ = null;
	public final String ______ = null;
	public final String ________ = null;
	public final String _________ = null;
	public final String __________ = null;
	public final String ___________ = null;
	public final String ____________ = null;
	public final String _____________ = null;
	public final String ______________ = null;
	public final String _______________ = null;
	public final String ________________ = null;
	public final String _________________ = null;
	public final String __________________ = null;
	public final String ___________________ = null;
	public final String _____________________ = null;
	public final String ______________________ = null;
	public final String _______________________ = null;
	public final String ________________________ = null;
	public final String _________________________ = null;
	public final String __________________________ = null;
	public final String ___________________________ = null;
	public final String ____________________________ = null;
	public final String _____________________________ = null;
	public final String ______________________________ = null;
	public final String _______________________________ = null;
	public final String ________________________________ = null;
	public final String _________________________________ = null;
	public final String __________________________________ = null;
	public final String ___________________________________ = null;

	public void selectProc() {
		System.out.println("selectProc executed.");
	}

	public void DISPLAY(Item obj) {
		System.out.println(obj.getString());
	}

	public void DISPLAY(String str) {
		System.out.println(str);
	}

	public void PERFORM(Object objfrom) {
		System.out.println("PERFORM executed.");
	}

	public final void EVALUATE(Object objfrom, Object objto) {
		System.out.println("EVALUATE executed.");
	}

	public boolean EVALUATE(Object objfrom, Object objto, Object obj1, Object obj2, Object obj3, Object obj4) {
		System.out.println("EVALUATE executed.");
		return true;
	}

	public boolean EVALUATE(Object objfrom, Object objto, Object obj1, Object obj2, Object obj3) {
		System.out.println("EVALUATE executed.");
		return true;
	}

	public boolean EVALUATE(Object objfrom, Object objto, Object obj1, Object obj2, Object obj3, Object obj4,
			Object obj5) {
		System.out.println("EVALUATE executed.");
		return true;
	}

	public boolean EVALUATE(Object objfrom, Object objto, Object obj1, Object obj2, Object obj3, Object obj4,
			Object obj5, Object obj6, Object obj7) {
		System.out.println("EVALUATE executed.");
		return true;
	}

	public boolean EVALUATE(Object objfrom, Object objto, Object obj1, Object obj2, Object obj3, Object obj4,
			Object obj5, Object obj6) {
		System.out.println("EVALUATE executed.");
		return true;
	}

	public void WHEN(Object objfrom, Object objto) {
		System.out.println("WHEN executed.");
	}

	public void END_EVALUATE() {
		System.out.println("END_EVALUATE executed.");
	}

	public void INITIALIZE(Item obj1) {
		obj1.setString("");//INITIALIZEは、何をすべき? PIC Xなら空白または0x00?  PIC9なら0? 編集項目は、空白か
	}
	public void INITIALIZE(Item obj1,Item obj2) {
		obj1.setString("");
		obj2.setString("");
	}
	public void INITIALIZE(Item obj1,Item obj2,Item obj3) {
		obj1.setString("");
		obj2.setString("");
		obj3.setString("");
	}
	public void INITIALIZE(Item obj1,Item obj2,Item obj3,Item obj4) {
		obj1.setString("");
		obj2.setString("");
		obj3.setString("");
		obj4.setString("");
	}

	public void MOVE(Item objfrom, Item objto) {
		objto.setString(objfrom.toString());
	}

	public void MOVE(String str, Item objto) {
		objto.setString(str);
	}
	public void MOVE(String str, Item objto1,Item objto2) {
		objto1.setString(str);
		objto2.setString(str);
	}
	public void MOVE(String str, Item objto1,Item objto2,Item objto3) {
		objto1.setString(str);
		objto2.setString(str);
		objto3.setString(str);
	}
	public void MOVE(String str, Item objto1,Item objto2,Item objto3,Item objto4) {
		objto1.setString(str);
		objto2.setString(str);
		objto3.setString(str);
		objto4.setString(str);
	}

	public void MOVE(Integer tempint, Item objto) {
		objto.setInt(tempint);
	}

	public void COMPUTE(long l) {
		System.out.println("COMPUTE executed.");
	}

	//	public void MOVE(Object objfrom, String str, Object objaa, Object objto) {
	//		System.out.println("MOVE2");
	//	}

	public byte[] init(Object DataDivisionArrayobj[][]) throws Exception {
		byte[] RecData = null;
		int level_column[] = new int[50];
		int level_before = 0;
		int level_now = 0;
		int level_lowest = 0;
		int level_picposition[] = new int[50];//PICの位置計算
		int level_picposition_fornext[] = new int[50];//PICの位置計算
		int occurs = 0;
		String picformat = "";
		int piclen = 0;
		int line_level[] = new int[DataDivisionArrayobj.length];//指定行におけるLevel
		int line_occurs[] = new int[DataDivisionArrayobj.length];//指定行におけるOCCURSの数
		int line_nest[] = new int[DataDivisionArrayobj.length];//指定行におけるOCCURSのネストの数
		int line_piclen[] = new int[DataDivisionArrayobj.length];//指定行におけるPICの長さ
		String line_picinfo[] = new String[DataDivisionArrayobj.length];//指定行におけるPICの情報
		int line_picposition[] = new int[DataDivisionArrayobj.length];//
		int line_itemlen[] = new int[DataDivisionArrayobj.length];//
		String line_picvalue[] = new String[DataDivisionArrayobj.length];//指定行におけるVALUEの情報
		boolean line_redifines[] = new boolean[DataDivisionArrayobj.length];//redifines有無
		String line_picformat[] = new String[DataDivisionArrayobj.length];//

		for (int i = DataDivisionArrayobj.length - 1; i >= 0; i--) {
			piclen = 0;
			occurs = 0;
			line_picformat[i] = "";
			for (int j = 0; j < DataDivisionArrayobj[i].length; j++) {
				if (j == 0 && DataDivisionArrayobj[i][j] instanceof levelno) {
					if (((levelno) DataDivisionArrayobj[i][j]).livelno >= 50) {
						continue;
					}
					level_before = level_now;
					level_now = ((levelno) DataDivisionArrayobj[i][j]).livelno;
					line_level[i] = level_now;
					if (level_now > level_lowest) {
						level_lowest = level_now + 1;
					}
					j++;
					continue;
				}
				if (DataDivisionArrayobj[i][j] == PIC) {
					picformat = ((String) DataDivisionArrayobj[i][j + 1]);//PICの次の文字列をフォーマットとして取り込み
					line_picformat[i] = picformat;
					piclen = picformat.length();
					level_column[level_now - 1] += piclen;//レベル位置に加算
					line_piclen[i] = piclen;
					line_itemlen[i] = piclen;
					j++;
					continue;
				}
				if (DataDivisionArrayobj[i][j] == VALUE) {
					line_picvalue[i] = ((String) DataDivisionArrayobj[i][j + 1]);//PICの次の文字列をvalueとして取り込み
					j++;
					continue;
				}
				// 03 item PIC XX OCCURS 10 の形式
				if (piclen > 0 && DataDivisionArrayobj[i][j] == OCCURS) {
					occurs = ((int) DataDivisionArrayobj[i][j + 1]);//PICの次の文字列をフォーマットとして取り込み
					level_column[level_now - 1] += piclen * (occurs - 1);//レベル位置に加算
					line_occurs[i] = occurs;//指定行におけるOCCURSの数を退避
					line_itemlen[i] = piclen * occurs;
					j++;
					continue;
				}
				// 03 item OCCURS 10 の形式
				if (piclen == 0 && DataDivisionArrayobj[i][j] == OCCURS) {
					occurs = ((int) DataDivisionArrayobj[i][j + 1]);//PICの次の文字列をフォーマットとして取り込み
					line_occurs[i] = occurs;//指定行におけるOCCURSの数を退避
					int level_column_sum = 0;
					for (int k = level_now + 1; k < level_lowest; k++) {
						level_column_sum += level_column[k - 1];
						level_column[k - 1] = 0;
					}
					level_column[level_now - 1] += level_column_sum * occurs;
					line_itemlen[i] = level_column_sum * occurs;
					j++;
					continue;
				}
				// 03 item2 REDEFINE item1 の形式
				if ((piclen == 0 && DataDivisionArrayobj[i][j] == REDEFINE)
						|| (piclen == 0 && DataDivisionArrayobj[i][j] == REDEFINES)) {
					line_redifines[i] = true;
					j++;
					continue;
				}
			}
			if (piclen == 0 && occurs == 0 && level_now < level_before) {
				int level_column_sum = 0;
				for (int k = level_now + 1; k < level_lowest; k++) {
					level_column_sum += level_column[k - 1];
					level_column[k - 1] = 0;
				}
				if (line_redifines[i] == false) {
					level_column[level_now - 1] += level_column_sum;
				}
				line_itemlen[i] = level_column_sum;
			}
			line_picinfo[i] = "";//String配列初期化
		}

		/****************************/
		/*        REDIFINE対応について         */
		/****************************/
		//REDIFINESについては、REDIFINEがある項目の上位レベルから01レベルまで項目長が加算されているので引く必要がある。
		//引く長さは、REDIFINEの指定してある項目の長さ分。
		//REDIFINEの参照元の項目と項目長が違うならおかしいので本来エラーとしたい。
		//レベルが違うREDIFINEは無いんじゃないか。
		//もともと、同じレベルの直下に書くのが位置的に正しいと思うが、それ以外はエラーでよい。

		//OCCURSの数、1要素の長さ、OCCURS全体の長さ、ネストの数を求める
		int ocurs = 0;
		for (int i = 0; i < DataDivisionArrayobj.length; i++) {
			if (line_occurs[i] > 0) {
				ocurs = line_occurs[i];
				line_picinfo[i] += "+" + String.format("%05d", ocurs) + String.format("%06d", line_itemlen[i] / ocurs)
						+ String.format("%06d", line_itemlen[i]);
				line_nest[i]++;
				for (int j = i + 1; j < DataDivisionArrayobj.length; j++) {
					//下位レベルの関係にある行
					if (line_level[j] > line_level[i]) {
						line_nest[j] = line_nest[j] + 1;
						line_picinfo[j] += "+" + String.format("%05d", ocurs)
								+ String.format("%06d", line_itemlen[i] / ocurs)
								+ String.format("%06d", line_itemlen[i]);
					} else {
						break;
					}
				}
			}
		}

		/****************************/
		/*        REDIFINE対応について         */
		/****************************/
		//もともと、同じレベルの直下に書くのが位置的に正しいと思うが、それ以外はエラーでよい。
		//OCCURSの解析には、影響はないと思われる。REDIFINE指定内で使われていれも問題ない。下位レベルのみ検索するので、REDIFINESは同レベルのため

		//項目の絶対カラム位置を求める
		int level = line_level[0];
		int len = line_itemlen[0];
		level_picposition_fornext[level] = len;
		for (int i = 1; i < DataDivisionArrayobj.length; i++) {
			level = line_level[i];
			len = line_itemlen[i];

			if (line_redifines[i] == true) {
				//System.out.println(level + " " + level_picposition[level] + " " + line_picinfo[i]);
				line_picposition[i] = level_picposition[level];
				continue;
			}
			//下位レベルの関係にある行
			if (line_level[i] > line_level[i - 1]) {
				level_picposition_fornext[level] += len;
				level_picposition[level] = level_picposition[line_level[i - 1]];
				level_picposition_fornext[level] = level_picposition[level];
				level_picposition_fornext[level] += len;
				//System.out.println(level + " " + level_picposition[level] + " " + line_picinfo[i]);
				line_picposition[i] = level_picposition[level];
				continue;
			}
			//上位レベルの関係にある行
			if (line_level[i] < line_level[i - 1]) {
				level_picposition[level] = level_picposition_fornext[level];
				level_picposition_fornext[level] += len;
				//System.out.println(level + " " + level_picposition[level] + " " + line_picinfo[i]);
				line_picposition[i] = level_picposition[level];
				continue;
			}
			//同じレベルの関係にある行
			if (line_level[i] == line_level[i - 1]) {
				level_picposition[level] = level_picposition_fornext[level];
				level_picposition_fornext[level] += len;
				//System.out.println(level + " " + level_picposition[level] + " " + line_picinfo[i]);
				line_picposition[i] = level_picposition[level];
				continue;
			}
		}

		RecData = new byte[level_column[0]];

		System.out.println("-----");
		for (int i = 0; i < DataDivisionArrayobj.length; i++) {
			if (DataDivisionArrayobj[i][0] instanceof levelno) {
				System.out.println("行 " + (i + 1));
				System.out.println("LEVEL " + line_level[i]);
				System.out.println("OCCURS数　1要素長　全要素長 " + line_picinfo[i]);
				System.out.println("OCCURSネスト数 " + line_nest[i]);
				System.out.println("PIC長 " + line_piclen[i]);
				System.out.println("PIC開始位置 " + line_picposition[i]);
				System.out.println("PIC FORMAT " + line_picformat[i]);
				System.out.println("PIC VALUE " + line_picvalue[i]);
				System.out.println("Item長" + line_itemlen[i]);
				System.out.println("-----");
				if (DataDivisionArrayobj[i][1] instanceof Item) {
					Item tempitem = (Item) DataDivisionArrayobj[i][1];
					tempitem.col = line_picposition[i];
					tempitem.len = line_itemlen[i];
					tempitem.pic = line_picformat[i];
					tempitem.setRecBytes(RecData);//レコードデータをセット
					if (tempitem.pic.length() > 0 && line_picvalue[i].length() > 0) {
						tempitem.setString(line_picvalue[i]);
					}
				} else if (DataDivisionArrayobj[i][1] instanceof Item[]) {
					if (line_nest[i] != 1) {
						System.out.println("DataDivisionArray[" + i + "] level(" + String.format("%02d", line_level[i])
								+ ") the item's array dimension does not match to occurs's nesting level.");
						return null;
					}
					Item tempitemD1[] = (Item[]) DataDivisionArrayobj[i][1];
					if (tempitemD1.length < Integer.parseInt(line_picinfo[i].substring(0, 6))) {
						System.out.println("DataDivisionArray[" + i + "] level(" + String.format("%02d", line_level[i])
								+ ") the item's array dimension does not enough to occurs's nesting level."
								+ tempitemD1.length + " < " + Integer.parseInt(line_picinfo[i].substring(0, 6)));
						return null;
					}
					for (int d1 = 0; d1 < Integer.parseInt(line_picinfo[i].substring(0, 6)); d1++) {
						tempitemD1[d1] = new Item();
						tempitemD1[d1].col = line_picposition[i]
								+ d1 * Integer.parseInt(line_picinfo[i].substring(6, 12));
						tempitemD1[d1].len = line_itemlen[i];
						tempitemD1[d1].pic = line_picformat[i];
						tempitemD1[d1].setRecBytes(RecData);//レコードデータをセット
					}
				} else if (DataDivisionArrayobj[i][1] instanceof Item[][]) {
					if (line_nest[i] != 2) {
						System.out.println("DataDivisionArray[" + i + "] level(" + String.format("%02d", line_level[i])
								+ ") the item's array dimension does not match to occurs's nesting level.");
						return null;
					}
					Item tempitemD2[][] = (Item[][]) DataDivisionArrayobj[i][1];
					if (tempitemD2.length < Integer.parseInt(line_picinfo[i].substring(0, 6))) {
						System.out.println("DataDivisionArray[" + i + "] level(" + String.format("%02d", line_level[i])
								+ ") the item's array dimension does not enough to occurs's nesting level."
								+ tempitemD2.length + " < " + Integer.parseInt(line_picinfo[i].substring(0, 6)));
						return null;
					}
					if (tempitemD2[0].length < Integer.parseInt(line_picinfo[i].substring(18, 18 + 6))) {
						System.out.println("DataDivisionArray[" + i + "] level(" + String.format("%02d", line_level[i])
								+ ") the item's array dimension does not enough to occurs's nesting level."
								+ tempitemD2[0].length + " < "
								+ Integer.parseInt(line_picinfo[i].substring(18, 18 + 6)));
						return null;
					}
					for (int d1 = 0; d1 < Integer.parseInt(line_picinfo[i].substring(0, 6)); d1++) {
						for (int d2 = 0; d2 < Integer.parseInt(line_picinfo[i].substring(18, 18 + 6)); d2++) {
							tempitemD2[d1][d2] = new Item();
							tempitemD2[d1][d2].col = line_picposition[i]
									+ d1 * Integer.parseInt(line_picinfo[i].substring(6, 12))
									+ d2 * Integer.parseInt(line_picinfo[i].substring(18 + 6, 18 + 6 + 6));
							tempitemD2[d1][d2].len = line_itemlen[i];
							tempitemD2[d1][d2].pic = line_picformat[i];
							tempitemD2[d1][d2].setRecBytes(RecData);//レコードデータをセット
						}
					}
				} else if (DataDivisionArrayobj[i][1] instanceof Item[][]) {
					if (line_nest[i] != 3) {
						System.out.println("DataDivisionArray[" + i + "] level(" + String.format("%02d", line_level[i])
								+ ") the item's array dimension does not match to occurs's nesting level.");
						return null;
					}
					Item tempitemD3[][][] = (Item[][][]) DataDivisionArrayobj[i][1];
					for (int d1 = 0; d1 < Integer.parseInt(line_picinfo[i].substring(0, 6)); d1++) {
						for (int d2 = 0; d2 < Integer.parseInt(line_picinfo[i].substring(18, 18 + 6)); d2++) {
							for (int d3 = 0; d3 < Integer.parseInt(line_picinfo[i].substring(36, 36 + 6)); d3++) {
								tempitemD3[d1][d2][d3] = new Item();
								tempitemD3[d1][d2][d3].col = line_picposition[i]
										+ d1 * Integer.parseInt(line_picinfo[i].substring(6, 12))
										+ d2 * Integer.parseInt(line_picinfo[i].substring(18 + 6, 18 + 6 + 6))
										+ d3 * Integer.parseInt(line_picinfo[i].substring(36 + 6, 36 + 6 + 6));
								System.out.println(tempitemD3[d1][d2][d3].col);
								tempitemD3[d1][d2][d3].len = line_itemlen[i];
								tempitemD3[d1][d2][d3].pic = line_picformat[i];
								tempitemD3[d1][d2][d3].setRecBytes(RecData);//レコードデータをセット
							}
						}
					}
				} else if (DataDivisionArrayobj[i][1] instanceof Item[][]) {
					Item tempitemD4[][][][] = (Item[][][][]) DataDivisionArrayobj[i][1];
				}
			}
		}

		//		System.out.println("obj長さ" + DataDivisionArrayobj.length);
		//		//PIC,VALUEなどをitemにセットする
		//		for (
		//
		//				int i = 0; i < DataDivisionArrayobj.length; i++) {
		//			Object obj2[] = DataDivisionArrayobj[i];
		//			for (int j = 0; j < obj2.length; j++) {
		//				if (obj2[j] == PIC) {
		//					String picformat2 = ((String) obj2[j + 1]);
		//					_01levellen = _01levellen + picformat2.length();
		//				}
		//			}
		//		}
		//		RecData = new byte[_01levellen];
		//
		//		//PIC,VALUEなどをitemにセットする
		//		System.out.println("obj長さ" + DataDivisionArrayobj.length);
		//		for (int i = 0; i < DataDivisionArrayobj.length; i++) {
		//			Object obj2[] = DataDivisionArrayobj[i];
		//			//Item itemobj = null;
		//			Item itemobjoccurs[] = null;
		//			for (int j = 0; j < obj2.length; j++) {
		//				//レベル番号か?
		//				System.out.println("i=" + i + " j=" + j);
		//				if (obj2[j] instanceof levelno) {
		//					System.out.println("LEVEL=" + ((levelno) obj2[j]).livelno);
		//					if (obj2[j + 1] == FILLER) {
		//						System.out.println("FILLER");
		//						itemobj = new Item();
		//					} else {
		//						if (((levelno) obj2[j]).livelno == 5) {//OCCURSのとき、OCCURSの次元数にあわせて変数にセット。
		//							//その後PICがあればOCCURSすべてのItemにVALUEなどセットする必要がある
		//							//桁位置を計算するためには、OCCURSのネスト数をもつ必要がある。
		//							itemobjoccurs = (Item[]) obj2[j + 1];//レベル番号の次は項目であるので取得
		//						} else {
		//							itemobj = (Item) obj2[j + 1];//レベル番号の次は項目であるので取得
		//						}
		//						itemobj.setRecBytes(RecData);//レコードデータをセット
		//					}
		//				}
		//				if (obj2[j] == PIC) {
		//					System.out.println("PIC");
		//					itemobj.pic = ((String) obj2[j + 1]);//PICの次の文字列をフォーマットとして取り込み
		//					itemobj.col = col;//桁位置を設定
		//					itemobj.len = itemobj.pic.length();//フォーマットの長さをセット今のことろXXX形式のみ
		//					col = col + itemobj.len;
		//				}
		//				if (obj2[j] == VALUE) {
		//					System.out.println("VALUE");
		//					String valueString = ((String) obj2[j + 1]);
		//					for (int bi = 0; bi < valueString.length() && bi < itemobj.len; bi++) {
		//						//itemobj.BytesValue[bi] = (byte) valueString.charAt(bi);
		//						RecData[(int) (itemobj.col + bi)] = (byte) valueString.charAt(bi);
		//					}
		//					itemobj.setString(valueString);
		//				}
		//			}
		//		}
		return RecData;
	}

}
