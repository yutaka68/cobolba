package cobdef;

public interface fileAccessInterface{
	public void OPEN() throws Exception;
	public Object READ(Item paraitem) throws Exception;
	public void CLOSE() throws Exception;
	public void WRITE(Item paraitem) throws Exception;
}
