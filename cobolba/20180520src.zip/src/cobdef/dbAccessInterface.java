package cobdef;

import java.util.ArrayList;

public interface dbAccessInterface {
	public void OPEN() throws Exception;
	public Object READ(Item paraitem) throws Exception;
	public Object READ(ArrayList<Item> selectlist) throws Exception;
	public void setkeylist(ArrayList<Item> keylist);
	public void setselectlist(ArrayList<Item> selectlist);
	public void WRITE(ArrayList<Item> insertlist) throws Exception;
	public void CLOSE() throws Exception;
}
