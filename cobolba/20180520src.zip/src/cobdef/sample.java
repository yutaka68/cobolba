//package cobdef;
//
//public class sample {
//	000170     PERFORM TEST BEFORE
//	000180         VARYING COUNTER FROM 1 BY 1 UNTIL COUNTER > 26
//	000230         IF IN-DATA = CHAR(COUNTER) THEN
//	000250             EXIT PERFORM
//	000260         END-IF
//	000270     END-PERFORM.
//
//	//株式会社システムズリサーチさん　メンテしたくないレベル
//	for (COUNTER_ins.set(".COUNTER", 1L); ;COUNTER_ins.add(".COUNTER", 1L)) {
//		if (COBOLUtil.cond(COUNTER_ins.get(".COUNTER"), ">", 26L)) {
//			break;
//		}
//		if (COBOLUtil.cond(IN_DATA_ins.get(".IN_DATA"), "==", ALP_ins.get(".ALP").substring(COUNTER_ins.getN(".COUNTER").longValue(), 1L))) {
//			break;
//		}
//	}
//	//予定としては以下のようだが、やや見にくい
//	for(COUNTER.setInt(1);!(COUNTER.getInt()>26);COUNTER.add(1)) {
//		if (IN_DATA != CHAR[COUNTER.getInt()]) {
//			return;
//		}
//	}
//	//本当はこうしたいが、できない。COUNTERをInt型として定義すればできる。これが一番いい。
//	for(COUNTER=1;!(COUNTER>26);COUNTER++) {
//		if (IN_DATA != CHAR[COUNTER]) {
//			return;
//		}
//	}
//	//これでも可 PERFORM内の添え字は、i,j,k,lに統一
//	for(int i=1;!(i>26);i++) {
//これは、後続で必要なければいらないが。PERFORMの添え字と配列指定だけで使用する変数はInt型にしたい。
//		COUNTER.setInt(i);
//条件としては、
//1. COUNTERが全ソース上、MOVE文でItemからの設定に使用されていないこと。
//2. PERFORMの外側の使用がないこと。
//3. 定義が01レベルであり独立していること。
//4. 99などの数字の整数であること。
//		if (IN_DATA != CHAR[i]) {
//			return;
//		}
//	}
//
//}
