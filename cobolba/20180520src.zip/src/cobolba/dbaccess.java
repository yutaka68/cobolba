package cobolba;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;

import cobdef.Item;
import cobdef.cob;
import cobdef.dbAccessInterface;

public class dbaccess extends cob implements dbAccessInterface {
	BufferedReader localreader = null;
	Charset localcharsets = null;
	String tablename = "";

	public void OPEN() {
		//		try {
		//		} catch (IOException e) {
		//		}
	}

	public Object READ(Item paraitem) throws Exception {
		String str = null;
		//			try {
		//			} finally {
		//				try {
		//				} catch (IOException e) {
		//				}
		//			}
		if (str == null) {
			return AT_END;
		} else {
			return NOT_AT_END;
		}
	}

	public void WRITE(Item paraitem) throws Exception {
		String str = null;
		//			try {
		//			} finally {
		//				try {
		//				} catch (IOException e) {
		//				}
		//			}
			return ;
	}

	public Object READ(ArrayList<Item> selectlist) throws Exception {
		String str = null;
		//		try {
		//		} finally {
		//			try {
		//			} catch (IOException e) {
		//			}
		//		}
		if (str == null) {
			return AT_END;
		} else {
			return NOT_AT_END;
		}
	}

	public void WRITE(ArrayList<Item> insertlist) throws Exception {
		String str = null;
		//		try {
		//		} finally {
		//			try {
		//			} catch (IOException e) {
		//			}
		//		}
		return;
	}

	public void setkeylist(ArrayList<Item> keylist) {

	}

	public void setselectlist(ArrayList<Item> selectlist) {

	}

	public void CLOSE() {
		try {
			if (this.localreader != null) {
				this.localreader.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
