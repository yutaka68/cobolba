package cobolba;

public class PGID1320 extends PGID1320DataDivision {
	public void doProc() throws Exception {

		idx = 1;//インデックスのみで使用しているものは、整数型で定義
		DISPLAY(KyousaiId);
		DISPLAY(ShokuinNametblD1[0]);

		myFile1.OPEN();
		myFile2.OPEN();
		myTable1.OPEN();
		myTable2.OPEN();

		/**************************/
		/*       DBの読み書き            */
		/**************************/
		while (true) {
			if (myTable1.READ(ShokuinMasterRec) == AT_END) {//レコードをバイト列としてDBリードする場合
				//AT ENDの処理
				break;
			}
			//NOT AT ENDの処理
			myTable1.WRITE(ShokuinMasterRec);//レコードをバイト列としてDB登録する場合
		}

		while (true) {
			if (myTable1.READ(myTable1_selectlist) == AT_END) {//DBをSELECTしてそれぞれのItemに代入する場合
				//AT ENDの処理
				break;
			}
			//NOT AT ENDの処理
			myTable1.WRITE(ShokuinMasterRec);//レコードをバイト列としてDB登録する場合
		}

		/**************************/
		/*       ファイルの読み書き            */
		/**************************/
		while (true) {
			if (myFile1.READ(ShokuinMasterRec) == AT_END) {
				//AT ENDの処理
			}
			//NOT AT ENDの処理
			myFile1.WRITE(ShokuinMasterRec);//ファイルの書き込み例
			break;
		}

		myFile1.CLOSE();
		myFile2.CLOSE();
		myTable1.CLOSE();
		myTable2.CLOSE();

		//MOVE文記載例
		INITIALIZE(ShokuinMasterRec);
		INITIALIZE(ShokuinId,ShokuinName);

		//MOVE文記載例
		MOVE("75", ShokuinId,ShokuinName);
		MOVE("75", ShokuinId);
		DISPLAY(ShokuinId);

		//CALL文記載例
		PGID1350 PGID1350 = new PGID1350();//毎回newしなきゃいけないもの?
		PGID1350.doProc(ShokuinId, ShokuinName);

		//OCCURS文使用記載例
		MOVE("75", aaaNametblD1[0]);
		MOVE("75", ShokuinNametblD2[0][3]);

		//COMPUTE記載例
		ShokuinId.COMPUTE(ShokuinId.getInt() + ShokuinId.getInt());
		DISPLAY(ShokuinId);

		//COMPUTE記載例
		ShokuinId.COMPUTE(ROUNDED, ShokuinId.getInt() + ShokuinId.getInt());

		//		//文字列部分参照記載例
		//		MOVE(ShokuinId.substring(3,4), ShokuinId);
		//		MOVEtoSubstring(ShokuinId,ShokuinId,3,4);
		//		MOVEfromSubstring(ShokuinId,,3,4,ShokuinId);
		//		MOVEfromtoSubstring(ShokuinId,,3,4,ShokuinId,2,3);
		//		//直近のsubstring指定を取っておいてその位置に入れる方法があるが、きれいでない
		//Itemオブジェクトはthruで値判定できる 便利機能 not_allとか、less_or_equalとか、あると便利 あり過ぎても探しにくいのでほどほどに
		if (ShokuinId.THRU("00", "50")) {
			MOVE(ShokuinName, ShokuinName);
		}

		//Itemオブジェクトはequalsで値判定できる
		if (ShokuinId.equals("00")) {
			MOVE(ShokuinName, ShokuinName);
		}

		if (ShokuinId.equals(0)) {
			MOVE(ShokuinName, ShokuinName);
		}
		MOVE("wada", ShokuinName);
		System.out.println(ShokuinName.getString());

		//EVALUATE文記載例　コボラーにとっては、見やすいはず
		if (EVALUATE(ShokuinId, ShokuinId, WHEN, 5, "4")) {
		}
		if (EVALUATE(ShokuinId, ShokuinId, WHEN, "2", "3")) {
		}
		if (EVALUATE(TRUE, ALSO, FALSE, WHEN, ShokuinId.THRU(2, 3), ALSO, ShokuinId.THRU("00", "50"))) {
		}

		//PERFORM記載例
		test1();//THRUはコメントにして置き換える　出口へのTHRUは、なくしてもよいがそうでないものは、手作業の対応が必要

		//		//PERFORM記載例 THRUは対応できないので不可 わざわざPERFORMにする必要ある?
		//		//PERFORM(selectProc);
		//
		//		//EVALUATEでないIFの記載例
		//		if (ShokuinId.equals("5") && ShokuinId.equals("5")) {
		//			MOVE(ShokuinName, ShokuinName);
		//		}
		//		if (ShokuinId.equals("2") && ShokuinId.equals(3)) {
		//			MOVE(ShokuinName, ShokuinName);
		//		}
		//		if (ShokuinId.equals("2") && (ShokuinId.getLong() >= 3) && (ShokuinId.getLong() <= 5)) {
		//			MOVE(ShokuinName, ShokuinName);
		//		}
		//		if (ShokuinId.equals("2") && (ShokuinId.greaterOrEqual(3)) && (ShokuinId.lessOrEqual(3))) {
		//			MOVE(ShokuinName, ShokuinName);
		//		}
		//
		//		if (ShokuinId.equals("5") && ShokuinId.equals("5")) {
		//			MOVE(ShokuinName, ShokuinName);
		//		}

		//READ,WRITE,SORT系
		//DBアクセス系
	}

	public void test1() {
		DISPLAY(ShokuinId);
		return;
	}
}
