package cobolba;

import java.util.ArrayList;

import cobdef.Item;
import cobdef.cob;

public class PGID1320DataDivision extends cob {

	PGID1320DataDivision() {
		try {
			DataDivisionBytes = init(DataDivisionArray);

			myTable1_keylist.add(KyousaiId);//select のwhere句比較用
			myTable1_keylist.add(KyousaiId);
			myTable1.setkeylist(myTable1_keylist);
			myTable1_selectlist.add(KyousaiId);//select 取得item用
			myTable1_selectlist.add(KyousaiId);
			myTable1.setselectlist(myTable1_selectlist);

			myTable2_keylist.add(KyousaiId);//select のwhere句比較用
			myTable2_keylist.add(KyousaiId);
			myTable2.setkeylist(myTable2_keylist);
			myTable2_selectlist.add(KyousaiId);//select 取得item用
			myTable2_selectlist.add(KyousaiId);
			myTable2.setselectlist(myTable2_selectlist);

			myFile1.setfile("c:\\aaa\\bbb\\ccc.txt");//FILE CONTROLL SECTIONの実ファイルのパスを指定
			myFile2.setfile("c:\\aaa\\bbb\\ddd.txt");//FILE CONTROLL SECTIONの実ファイルのパスを指定

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	byte DataDivisionBytes[];
	Item KyousaiId = new Item("共済ID");
	Item ShokuinId = new Item("ShokuinId");
	Item ShokuinNa = new Item();
	Item ShokuinName = new Item();
	Item ShokuinMasterRec = new Item("職員マスタレコード");
	Item SyozokuMasterRec = new Item();
	Item _8Shokuinkana = new Item();//数字で始まる項目はアンスコ付ける
	Item[] ShokuinNametblD1 = new Item[7];//配列
	Item[] aaaNametblD1 = new Item[10];//配列
	Item[][] ShokuinNametblD2 = new Item[10][7];//配列
	Item[][][] ShokuinNametblD3 = new Item[3][7][7];//配列

	fileaccess myFile1 = new fileaccess();//ファイルのアクセスの場合
	fileaccess myFile2 = new fileaccess();//ファイルのアクセスの場合

	ArrayList<Item> myTable1_keylist = new ArrayList<Item>();
	ArrayList<Item> myTable1_selectlist = new ArrayList<Item>();
	dbaccess myTable1 = new dbaccess();//DBのアクセスの場合

	ArrayList<Item> myTable2_keylist = new ArrayList<Item>();
	ArrayList<Item> myTable2_selectlist = new ArrayList<Item>();
	dbaccess myTable2 = new dbaccess();//DBのアクセスの場合

	int idx = 0;

	/* 同じ項目名の対策について
	 * 同じ項目名がある場合、COBOLではOF,INをつけて一意に指定できる。
	 * それを自動変換するための方法として01レベルを内部クラスにする方法があるが、使用時、毎回内部クラスを指定しないといけない。
	 * かなり読みづらさがでてくる。重複項目名がある場合は、01レベルの項目名を追加するなど項目名を一意にすればよい。
	 * そのほうが簡単だし、手直しも楽。もともと重複項目名はCOBOL上も読みづらさがでてくるので多様しない。
	 */
	public Object DataDivisionArray[][] = { //
			{ _01, ShokuinMasterRec }, //
			{ ___03, ShokuinNametblD1, ____________, OCCURS, 3 }, //
			{ _____05, ShokuinNametblD2, __________, OCCURS, 7 }, //
			{ _______07, ShokuinNametblD3, ________, PIC, "X", OCCURS, 7 }, //
			{ _____05, ShokuinNametblD1 }, //
			{ _______07, ShokuinNametblD2, ________, PIC, "X", OCCURS, 7 }, //
			{ _____05, ShokuinNametblD1, __________, REDEFINES, ShokuinNametblD1 }, //
			{ _______07, ShokuinNametblD2, ________, PIC, "X", OCCURS, 2 }, //
			{ _______07, ShokuinNametblD2, ________, PIC, "X", OCCURS, 5 }, //
			{ _____05, ShokuinNa, REDEFINES, ShokuinNametblD1 }, //
			{ _______07, ShokuinNametblD2, ________, PIC, "X", OCCURS, 2 }, //
			{ _______07, ShokuinNametblD2, ________, PIC, "X", OCCURS, 5 }, //
			{ ___03, ShokuinId, ___________________, PIC, "XX", VALUE, "00" }, //
			{ ___03, ShokuinId, ___________________, PIC, "XX", VALUE, "12" }, //
			{ ___03, aaaNametblD1, ________________, OCCURS, 10 }, //
			{ _____05, KyousaiId, __________________, PIC, "XX", VALUE, "34" }, //
			{ _____05, ShokuinId }, //
			{ _______07, ShokuinNametblD2, _________, PIC, "X", OCCURS, 7 }, //
			{ _66, ShokuinId, ______________________, PIC, "XX", VALUE, "34" }, //
			{ _01, SyozokuMasterRec }, //
			{ ___03, FILLER, ______________________, PIC, "XX", VALUE, "56" }, //
			{ ___03, FILLER, ______________________, PIC, "XX", VALUE, "78" }, //
			{ ___03, ShokuinNa }, //
			{ _____05, ShokuinName, _______________, PIC, "XXXXXXX", VALUE, "0123" }, //
			//			{ ___03, ShokuinNa, _____________, REDEFINES, ShokuinNa }, //
			{ _____05, ShokuinNametblD1, ___________, PIC, "X", OCCURS, 7 }, //
			{ ___03, ShokuinNametblD1, _____________, OCCURS, 3 }, //
			{ _____05, ShokuinNametblD2, ___________, OCCURS, 7 }, //
			{ _______07, ShokuinNametblD3, __________, PIC, "X", OCCURS, 7 }, //
			//			{ ___03, ShokuinNa, ____________, REDEFINES, ShokuinNa }, //
			//			{ _____05, ShokuinNametbl2, _____, PIC, "X", OCCURS, 7 },//
	};
	//	public Object DataDivisionRecArray3[][] = { //
	//			{ _01, ShokuinMasterRec }, //
	//			{ ___03, ShokuinId, PIC, "XX", VALUE, "00" }, //
	//			{ _____05, ShokuinName, PIC, "XX", VALUE, "12" }, //
	//			{ _______07, ShokuinNa, PIC, "XX", VALUE, "34" }, //
	//			{ _______07, ShokuinId, PIC, "XX", VALUE, "56" }, //
	//			{ _____05, ShokuinNa, PIC, "XX", VALUE, "78" }, //
	//			{ ___03, ShokuinNa }, //
	//			{ _____05, ShokuinName, PIC, "XXXXXXX", VALUE, "0123" }, //
	//			{ _01, ShokuinMasterRec }, //
	//			{ ___03, ShokuinName, PIC, "XX", VALUE, "00" }, //
	//			{ _____05, ShokuinNametbl2, PIC, "XX", VALUE, "12" }, //
	//			{ _____05, ShokuinNametbl, PIC, "XX", VALUE, "34" }, //
	//			{ _____05, ShokuinNa, PIC, "XX", VALUE, "56" }, //
	//			{ _______07, ShokuinNametbl, PIC, "XX", VALUE, "78" }, //
	//			{ ___03, ShokuinNa }, //
	//			{ _______07, ShokuinName, PIC, "XXXXXXX", VALUE, "0123" }, //
	//			{ _01, ShokuinMasterRec }, //
	//			{ ___03, ShokuinId, PIC, "XX", VALUE, "00" }, //
	//			{ ___03, ShokuinId, PIC, "XX", VALUE, "12" }, //
	//			{ ___03, ShokuinId, PIC, "XX", VALUE, "34" }, //
	//			{ ___03, ShokuinId, PIC, "XX", VALUE, "56" }, //
	//			{ ___03, ShokuinId, PIC, "XX", VALUE, "78" }, //
	//			{ ___03, ShokuinNa }, //
	//			{ _____05, ShokuinName, PIC, "XXXXXXX", VALUE, "0123" },//
	//	};
}
