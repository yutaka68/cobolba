package cobolba;

public class Cobmain {
	public static void main(String[] args) throws Exception {
		PGID1320 obj = new PGID1320();
		obj.doProc();
	}
}
