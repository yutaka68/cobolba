package cobolba;

import cobdef.Item;
import cobdef.cob;

public class PGID1350DataDivision extends cob {

	PGID1350DataDivision() {
		try {
			DataDivisionBytes = init(DataDivisionArray);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	byte DataDivisionBytes[];
	 Item ShokuinId2=new Item();
	 Item ShokuinNa=new Item();
	 Item ShokuinName=new Item();
	 Item ShokuinMasterRec=new Item();
	 Item proctorokuId = new Item();

	/* 同じ項目名の対策について
	 * 同じ項目名がある場合、COBOLではOF,INをつけて一意に指定できる。
	 * それを自動変換するための方法として01レベルを内部クラスにする方法があるが、使用時、毎回内部クラスを指定しないといけない。
	 * かなり読みづらさがでてくる。重複項目名がある場合は、01レベルの項目名を追加するなど項目名を一意にすればよい。
	 * そのほうが簡単だし、手直しも楽。もともと重複項目名はCOBOL上も読みづらさがでてくるので多様しない。
	 */
	public Object DataDivisionArray[][] = { //
			{ _01, ShokuinMasterRec }, //
			{ ___03, proctorokuId, PIC, "XX",VALUE,"00" }, //
			{ ___03, proctorokuId, PIC, "XX",VALUE,"12" }, //
			{ ___03, proctorokuId, PIC, "XX",VALUE,"34" }, //
			{ ___03, proctorokuId, PIC, "XX",VALUE,"56" }, //
			{ ___03, proctorokuId, PIC, "XX",VALUE,"78" }, //
			{ ___03, ShokuinNa },//
			{ _____05, ShokuinName, PIC, "XXXXXXX",VALUE,"0123" },//
	};
}
