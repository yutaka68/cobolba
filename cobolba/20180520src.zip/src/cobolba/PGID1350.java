package cobolba;

import cobdef.Item;

public class PGID1350 extends PGID1350DataDivision{
	public void doProc(Item torokuId, Item shokuinName) {
		MOVE(torokuId,proctorokuId);
		MOVE(shokuinName,proctorokuId);
		DISPLAY("torokuId="+proctorokuId.getString());
	}
}
