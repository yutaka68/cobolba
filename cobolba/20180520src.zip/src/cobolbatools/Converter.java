package cobolbatools;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

public class Converter {
	public static void main(String[] args) throws Exception {
		try {
			int procedure = 0;

			//書き込みファイル
			File outfile = new File("java.txt");
			// 文字コードを指定する
			PrintWriter p_writer = new PrintWriter(
					new BufferedWriter(new OutputStreamWriter(new FileOutputStream(outfile), "Shift-JIS")));

			//読み込みファイル
			File infile = new File("test.txt");
			BufferedReader b_reader = new BufferedReader(
					new InputStreamReader(new FileInputStream(infile), "Shift-JIS"));

			String line = b_reader.readLine();
			while (line != null) {
				System.out.println(line);

				//先頭の行番号を削除
				if (line.length() >= 7) {
					line = line.substring(7);
				}
				//73桁目以降を削除
				if (line.length() >= 65) {
					line = line.substring(0, 65);
				}
				String words[] = line.trim().split(" ", 0);
				if (words.length > 1) {
					if (words[0].equals("PROCEDURE") || words[1].equals("DIVISION.")) {
						procedure = 1;
					}
				}
				if (procedure == 0 && line.length() >= 2) {
					//レベル番号ありか
					if (isNumber(line.trim().substring(0, 2))) {
						String level = line.trim().substring(0, 2);
						String[] word = spritbywords(line);
						String itemname = "";
						String format = "";
						String occursnum = "";
						String valuestr = "";

						for (int i = 1; i < word.length; i++) {
							if (word[i].equals("VALUE") || word[i].equals("VALUES")) {
								if (i == word.length) {
									throw new Exception();
								}
								if (word[i + 1].equals("IS") || word[i + 1].equals("ARE")) {
									word[i + 1] = "";
								}
								if (i >= word.length) {
									throw new Exception();
								}

								String temp = "";
								for (i = i + 1; i < word.length; i++) {
									temp += word[i];
								}

								valuestr = temp;
								if (valuestr.endsWith(".")) {
									valuestr = valuestr.substring(0, valuestr.lastIndexOf("."));
								}
								continue;
							}
							if (word[i].equals("PIC") || word[i].equals("PICTURE")) {
								if (i == word.length) {
									throw new Exception();
								}
								if (word[i + 1].equals("IS")) {
									i = i + 1;
								}
								if (i == word.length) {
									throw new Exception();
								}
								format = word[i + 1];
								if (format.endsWith(".")) {
									format = format.substring(0, format.lastIndexOf("."));
								}
								continue;
							}
							if (word[i].equals("OCCURS")) {
								if (i == word.length) {
									throw new Exception();
								}
								if (isNumber(word[i + 1])) {
									occursnum = word[i + 1];
								}
								if (occursnum.endsWith(".")) {
									occursnum = occursnum.substring(0, occursnum.lastIndexOf("."));
								}
								continue;
							}

							//レベル番号 + FILLER句
							if (itemname.equals("")) {
								if (word[i].equals("FILLER")) {
									itemname = "FILLER";
									continue;
								} else {
									itemname = word[i];
									if (itemname.endsWith(".")) {
										itemname = itemname.substring(0, itemname.lastIndexOf("."));
									}
									itemname = itemname.replace("_", "__");
									itemname = itemname.replace("-", "_");
									continue;
								}
							}
						}

						String editline = "";

						editline = "{ __" + level + "";
						if (itemname.length() > 0) {
							editline = editline + ", " + itemname;
						}
						if (occursnum.length() > 0) {
							editline = editline + ", " + "OCCURS," + occursnum;
						}
						if (format.length() > 0) {
							editline = editline + ", " + "PIC," + "\"" + format + "\"";
						}
						if (valuestr.length() > 0) {
							if (valuestr.endsWith("\"")) {
								editline = editline + ", " + "VALUE," + valuestr;
							} else {
								editline = editline + ", " + "VALUE," + valuestr;
							}
						}

						editline = editline + " }, //";

						System.out.println(editline);
						//ファイルに文字列を書き込む
						p_writer.println(editline);
					}
				}
				line = b_reader.readLine();
			}

			//ファイルをクローズする
			p_writer.close();
			b_reader.close();
		} catch (IOException e) {
			System.out.println(e);
		}
	}

	static boolean isNumber(String num) {
		try {
			Integer.parseInt(num);
			return true;
		} catch (NumberFormatException e) {
			return false;
		}
	}

	static String[] spritbywords(String str) {

		String word[];
		String wordback[];
		String orderstr = "";
		String valuestr = "";

		if ((str.indexOf(" VALUE ") < 0) && (str.indexOf(" VALUES ") < 0)) {
			return str.trim().split(" ");
		}
		if (str.indexOf(" VALUE ") > 0) {
			//最初のVALUEのところまで
			orderstr = str.substring(0, str.indexOf(" VALUE ") + " VALUE ".length());

			//VALUEの後、最後までをVALUE文字列とする。
			valuestr = str.substring(str.indexOf(" VALUE ") + " VALUE ".length()).trim();
		} else {
			//最初のVALUESのところまで
			orderstr = str.substring(0, str.indexOf(" VALUES ") + " VALUES ".length());

			//VALUESの後、最後までをVALUES文字列とする。
			valuestr = str.substring(str.indexOf(" VALUES ") + " VALUES ".length()).trim();
		}

		if (valuestr.startsWith("IS ")) {
			orderstr = orderstr + "IS ";
			valuestr = valuestr.trim().substring("IS ".length());
		}
		if (valuestr.startsWith("ARE ")) {
			orderstr = orderstr + "ARE ";
			valuestr = valuestr.trim().substring("ARE ".length());
		}
		//&で終わる時は次の行も連結だけど・・・
		if (valuestr.trim().endsWith(" &")) {
		}
		//VALUEの後、ダブルクォートで終わるところまで
		valuestr = valuestr.substring(0, valuestr.lastIndexOf("\"") + 1);

		wordback = orderstr.trim().split(" ");

		word = new String[wordback.length + 1];
		int j = 0;
		for (int i = 0; i < wordback.length; i++) {
			if (wordback[i] != null && wordback[i].length() > 0) {
				word[j++] = wordback[i].trim();
			}
		}
		word[word.length - 1] = valuestr;
		//		System.out.println(orderstr);
		//		System.out.println(valuestr);
		for (int i = 0; i < word.length; i++) {
			//System.out.println(i + " " + word[i]);
		}
		return word;
	}
}
